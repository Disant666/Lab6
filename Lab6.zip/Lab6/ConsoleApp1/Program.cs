﻿using System;
using System.Globalization;
using System.Text;
using System.Threading;

namespace ExceptionHandlingLab
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            bool continueProgram = true;

            while (continueProgram)
            {
                try
                {
                    Console.Write("Введіть перше число: ");
                    double num1 = Convert.ToDouble(Console.ReadLine());

                    Console.Write("Введіть друге число: ");
                    double num2 = Convert.ToDouble(Console.ReadLine());

                    if (num2 == 0)
                    {
                        throw new DivideByZeroException();
                    }

                    double result = num1 / num2;
                    Console.WriteLine($"Результат ділення: {result}");
                }
                catch (DivideByZeroException)
                {
                    Console.WriteLine("Помилка: Ділення на нуль неможливе!");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Помилка: Будь ласка, введіть число у правильному форматі!");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Сталася помилка: " + ex.Message);
                }
                finally
                {
                    Console.WriteLine("Програма завершила цю спробу.\n");
                }

                Console.Write("Бажаєте спробувати ще раз? (так/ні): ");
                string answer = Console.ReadLine().Trim().ToLower();
                if (answer != "так" && answer != "yes")
                {
                    continueProgram = false;
                }
                Console.WriteLine();
            }

            Console.WriteLine("Програма повністю завершила свою роботу.");
        }
    }
}
